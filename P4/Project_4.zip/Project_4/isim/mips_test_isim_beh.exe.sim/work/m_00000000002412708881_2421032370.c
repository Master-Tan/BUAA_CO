/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "E:/ISE/Project_4/MUX.v";
static int ng1[] = {0, 0};
static int ng2[] = {1, 0};



static void Cont_77_0(char *t0)
{
    char t3[8];
    char t4[8];
    char t6[8];
    char t11[8];
    char t27[8];
    char t41[8];
    char t46[8];
    char t62[8];
    char t70[8];
    char t119[8];
    char t120[8];
    char t122[8];
    char t127[8];
    char t143[8];
    char t157[8];
    char t162[8];
    char t178[8];
    char t186[8];
    char t235[8];
    char t236[8];
    char t238[8];
    char t243[8];
    char t259[8];
    char t273[8];
    char t278[8];
    char t294[8];
    char t302[8];
    char *t1;
    char *t2;
    char *t5;
    char *t7;
    char *t8;
    char *t9;
    char *t10;
    char *t12;
    char *t13;
    unsigned int t14;
    unsigned int t15;
    unsigned int t16;
    unsigned int t17;
    unsigned int t18;
    unsigned int t19;
    unsigned int t20;
    unsigned int t21;
    unsigned int t22;
    unsigned int t23;
    unsigned int t24;
    unsigned int t25;
    char *t26;
    char *t28;
    unsigned int t29;
    unsigned int t30;
    unsigned int t31;
    unsigned int t32;
    unsigned int t33;
    char *t34;
    char *t35;
    unsigned int t36;
    unsigned int t37;
    unsigned int t38;
    char *t39;
    char *t40;
    char *t42;
    char *t43;
    char *t44;
    char *t45;
    char *t47;
    char *t48;
    unsigned int t49;
    unsigned int t50;
    unsigned int t51;
    unsigned int t52;
    unsigned int t53;
    unsigned int t54;
    unsigned int t55;
    unsigned int t56;
    unsigned int t57;
    unsigned int t58;
    unsigned int t59;
    unsigned int t60;
    char *t61;
    char *t63;
    unsigned int t64;
    unsigned int t65;
    unsigned int t66;
    unsigned int t67;
    unsigned int t68;
    char *t69;
    unsigned int t71;
    unsigned int t72;
    unsigned int t73;
    char *t74;
    char *t75;
    char *t76;
    unsigned int t77;
    unsigned int t78;
    unsigned int t79;
    unsigned int t80;
    unsigned int t81;
    unsigned int t82;
    unsigned int t83;
    char *t84;
    char *t85;
    unsigned int t86;
    unsigned int t87;
    unsigned int t88;
    unsigned int t89;
    unsigned int t90;
    unsigned int t91;
    unsigned int t92;
    unsigned int t93;
    int t94;
    int t95;
    unsigned int t96;
    unsigned int t97;
    unsigned int t98;
    unsigned int t99;
    unsigned int t100;
    unsigned int t101;
    char *t102;
    unsigned int t103;
    unsigned int t104;
    unsigned int t105;
    unsigned int t106;
    unsigned int t107;
    char *t108;
    char *t109;
    unsigned int t110;
    unsigned int t111;
    unsigned int t112;
    char *t113;
    char *t114;
    unsigned int t115;
    unsigned int t116;
    unsigned int t117;
    unsigned int t118;
    char *t121;
    char *t123;
    char *t124;
    char *t125;
    char *t126;
    char *t128;
    char *t129;
    unsigned int t130;
    unsigned int t131;
    unsigned int t132;
    unsigned int t133;
    unsigned int t134;
    unsigned int t135;
    unsigned int t136;
    unsigned int t137;
    unsigned int t138;
    unsigned int t139;
    unsigned int t140;
    unsigned int t141;
    char *t142;
    char *t144;
    unsigned int t145;
    unsigned int t146;
    unsigned int t147;
    unsigned int t148;
    unsigned int t149;
    char *t150;
    char *t151;
    unsigned int t152;
    unsigned int t153;
    unsigned int t154;
    char *t155;
    char *t156;
    char *t158;
    char *t159;
    char *t160;
    char *t161;
    char *t163;
    char *t164;
    unsigned int t165;
    unsigned int t166;
    unsigned int t167;
    unsigned int t168;
    unsigned int t169;
    unsigned int t170;
    unsigned int t171;
    unsigned int t172;
    unsigned int t173;
    unsigned int t174;
    unsigned int t175;
    unsigned int t176;
    char *t177;
    char *t179;
    unsigned int t180;
    unsigned int t181;
    unsigned int t182;
    unsigned int t183;
    unsigned int t184;
    char *t185;
    unsigned int t187;
    unsigned int t188;
    unsigned int t189;
    char *t190;
    char *t191;
    char *t192;
    unsigned int t193;
    unsigned int t194;
    unsigned int t195;
    unsigned int t196;
    unsigned int t197;
    unsigned int t198;
    unsigned int t199;
    char *t200;
    char *t201;
    unsigned int t202;
    unsigned int t203;
    unsigned int t204;
    unsigned int t205;
    unsigned int t206;
    unsigned int t207;
    unsigned int t208;
    unsigned int t209;
    int t210;
    int t211;
    unsigned int t212;
    unsigned int t213;
    unsigned int t214;
    unsigned int t215;
    unsigned int t216;
    unsigned int t217;
    char *t218;
    unsigned int t219;
    unsigned int t220;
    unsigned int t221;
    unsigned int t222;
    unsigned int t223;
    char *t224;
    char *t225;
    unsigned int t226;
    unsigned int t227;
    unsigned int t228;
    char *t229;
    char *t230;
    unsigned int t231;
    unsigned int t232;
    unsigned int t233;
    unsigned int t234;
    char *t237;
    char *t239;
    char *t240;
    char *t241;
    char *t242;
    char *t244;
    char *t245;
    unsigned int t246;
    unsigned int t247;
    unsigned int t248;
    unsigned int t249;
    unsigned int t250;
    unsigned int t251;
    unsigned int t252;
    unsigned int t253;
    unsigned int t254;
    unsigned int t255;
    unsigned int t256;
    unsigned int t257;
    char *t258;
    char *t260;
    unsigned int t261;
    unsigned int t262;
    unsigned int t263;
    unsigned int t264;
    unsigned int t265;
    char *t266;
    char *t267;
    unsigned int t268;
    unsigned int t269;
    unsigned int t270;
    char *t271;
    char *t272;
    char *t274;
    char *t275;
    char *t276;
    char *t277;
    char *t279;
    char *t280;
    unsigned int t281;
    unsigned int t282;
    unsigned int t283;
    unsigned int t284;
    unsigned int t285;
    unsigned int t286;
    unsigned int t287;
    unsigned int t288;
    unsigned int t289;
    unsigned int t290;
    unsigned int t291;
    unsigned int t292;
    char *t293;
    char *t295;
    unsigned int t296;
    unsigned int t297;
    unsigned int t298;
    unsigned int t299;
    unsigned int t300;
    char *t301;
    unsigned int t303;
    unsigned int t304;
    unsigned int t305;
    char *t306;
    char *t307;
    char *t308;
    unsigned int t309;
    unsigned int t310;
    unsigned int t311;
    unsigned int t312;
    unsigned int t313;
    unsigned int t314;
    unsigned int t315;
    char *t316;
    char *t317;
    unsigned int t318;
    unsigned int t319;
    unsigned int t320;
    unsigned int t321;
    unsigned int t322;
    unsigned int t323;
    unsigned int t324;
    unsigned int t325;
    int t326;
    int t327;
    unsigned int t328;
    unsigned int t329;
    unsigned int t330;
    unsigned int t331;
    unsigned int t332;
    unsigned int t333;
    char *t334;
    unsigned int t335;
    unsigned int t336;
    unsigned int t337;
    unsigned int t338;
    unsigned int t339;
    char *t340;
    char *t341;
    unsigned int t342;
    unsigned int t343;
    unsigned int t344;
    char *t345;
    char *t346;
    unsigned int t347;
    unsigned int t348;
    unsigned int t349;
    unsigned int t350;
    char *t351;
    char *t352;
    char *t353;
    char *t354;
    char *t355;
    char *t356;

LAB0:    t1 = (t0 + 3008U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(77, ng0);
    t2 = (t0 + 1048U);
    t5 = *((char **)t2);
    t2 = (t0 + 1008U);
    t7 = (t2 + 72U);
    t8 = *((char **)t7);
    t9 = ((char*)((ng1)));
    xsi_vlog_generic_get_index_select_value(t6, 32, t5, t8, 2, t9, 32, 1);
    t10 = ((char*)((ng1)));
    memset(t11, 0, 8);
    t12 = (t6 + 4);
    t13 = (t10 + 4);
    t14 = *((unsigned int *)t6);
    t15 = *((unsigned int *)t10);
    t16 = (t14 ^ t15);
    t17 = *((unsigned int *)t12);
    t18 = *((unsigned int *)t13);
    t19 = (t17 ^ t18);
    t20 = (t16 | t19);
    t21 = *((unsigned int *)t12);
    t22 = *((unsigned int *)t13);
    t23 = (t21 | t22);
    t24 = (~(t23));
    t25 = (t20 & t24);
    if (t25 != 0)
        goto LAB7;

LAB4:    if (t23 != 0)
        goto LAB6;

LAB5:    *((unsigned int *)t11) = 1;

LAB7:    memset(t27, 0, 8);
    t28 = (t11 + 4);
    t29 = *((unsigned int *)t28);
    t30 = (~(t29));
    t31 = *((unsigned int *)t11);
    t32 = (t31 & t30);
    t33 = (t32 & 1U);
    if (t33 != 0)
        goto LAB8;

LAB9:    if (*((unsigned int *)t28) != 0)
        goto LAB10;

LAB11:    t35 = (t27 + 4);
    t36 = *((unsigned int *)t27);
    t37 = *((unsigned int *)t35);
    t38 = (t36 || t37);
    if (t38 > 0)
        goto LAB12;

LAB13:    memcpy(t70, t27, 8);

LAB14:    memset(t4, 0, 8);
    t102 = (t70 + 4);
    t103 = *((unsigned int *)t102);
    t104 = (~(t103));
    t105 = *((unsigned int *)t70);
    t106 = (t105 & t104);
    t107 = (t106 & 1U);
    if (t107 != 0)
        goto LAB26;

LAB27:    if (*((unsigned int *)t102) != 0)
        goto LAB28;

LAB29:    t109 = (t4 + 4);
    t110 = *((unsigned int *)t4);
    t111 = *((unsigned int *)t109);
    t112 = (t110 || t111);
    if (t112 > 0)
        goto LAB30;

LAB31:    t115 = *((unsigned int *)t4);
    t116 = (~(t115));
    t117 = *((unsigned int *)t109);
    t118 = (t116 || t117);
    if (t118 > 0)
        goto LAB32;

LAB33:    if (*((unsigned int *)t109) > 0)
        goto LAB34;

LAB35:    if (*((unsigned int *)t4) > 0)
        goto LAB36;

LAB37:    memcpy(t3, t119, 8);

LAB38:    t345 = (t0 + 3408);
    t352 = (t345 + 56U);
    t353 = *((char **)t352);
    t354 = (t353 + 56U);
    t355 = *((char **)t354);
    memcpy(t355, t3, 8);
    xsi_driver_vfirst_trans(t345, 0, 31);
    t356 = (t0 + 3328);
    *((int *)t356) = 1;

LAB1:    return;
LAB6:    t26 = (t11 + 4);
    *((unsigned int *)t11) = 1;
    *((unsigned int *)t26) = 1;
    goto LAB7;

LAB8:    *((unsigned int *)t27) = 1;
    goto LAB11;

LAB10:    t34 = (t27 + 4);
    *((unsigned int *)t27) = 1;
    *((unsigned int *)t34) = 1;
    goto LAB11;

LAB12:    t39 = (t0 + 1048U);
    t40 = *((char **)t39);
    t39 = (t0 + 1008U);
    t42 = (t39 + 72U);
    t43 = *((char **)t42);
    t44 = ((char*)((ng2)));
    xsi_vlog_generic_get_index_select_value(t41, 32, t40, t43, 2, t44, 32, 1);
    t45 = ((char*)((ng1)));
    memset(t46, 0, 8);
    t47 = (t41 + 4);
    t48 = (t45 + 4);
    t49 = *((unsigned int *)t41);
    t50 = *((unsigned int *)t45);
    t51 = (t49 ^ t50);
    t52 = *((unsigned int *)t47);
    t53 = *((unsigned int *)t48);
    t54 = (t52 ^ t53);
    t55 = (t51 | t54);
    t56 = *((unsigned int *)t47);
    t57 = *((unsigned int *)t48);
    t58 = (t56 | t57);
    t59 = (~(t58));
    t60 = (t55 & t59);
    if (t60 != 0)
        goto LAB18;

LAB15:    if (t58 != 0)
        goto LAB17;

LAB16:    *((unsigned int *)t46) = 1;

LAB18:    memset(t62, 0, 8);
    t63 = (t46 + 4);
    t64 = *((unsigned int *)t63);
    t65 = (~(t64));
    t66 = *((unsigned int *)t46);
    t67 = (t66 & t65);
    t68 = (t67 & 1U);
    if (t68 != 0)
        goto LAB19;

LAB20:    if (*((unsigned int *)t63) != 0)
        goto LAB21;

LAB22:    t71 = *((unsigned int *)t27);
    t72 = *((unsigned int *)t62);
    t73 = (t71 & t72);
    *((unsigned int *)t70) = t73;
    t74 = (t27 + 4);
    t75 = (t62 + 4);
    t76 = (t70 + 4);
    t77 = *((unsigned int *)t74);
    t78 = *((unsigned int *)t75);
    t79 = (t77 | t78);
    *((unsigned int *)t76) = t79;
    t80 = *((unsigned int *)t76);
    t81 = (t80 != 0);
    if (t81 == 1)
        goto LAB23;

LAB24:
LAB25:    goto LAB14;

LAB17:    t61 = (t46 + 4);
    *((unsigned int *)t46) = 1;
    *((unsigned int *)t61) = 1;
    goto LAB18;

LAB19:    *((unsigned int *)t62) = 1;
    goto LAB22;

LAB21:    t69 = (t62 + 4);
    *((unsigned int *)t62) = 1;
    *((unsigned int *)t69) = 1;
    goto LAB22;

LAB23:    t82 = *((unsigned int *)t70);
    t83 = *((unsigned int *)t76);
    *((unsigned int *)t70) = (t82 | t83);
    t84 = (t27 + 4);
    t85 = (t62 + 4);
    t86 = *((unsigned int *)t27);
    t87 = (~(t86));
    t88 = *((unsigned int *)t84);
    t89 = (~(t88));
    t90 = *((unsigned int *)t62);
    t91 = (~(t90));
    t92 = *((unsigned int *)t85);
    t93 = (~(t92));
    t94 = (t87 & t89);
    t95 = (t91 & t93);
    t96 = (~(t94));
    t97 = (~(t95));
    t98 = *((unsigned int *)t76);
    *((unsigned int *)t76) = (t98 & t96);
    t99 = *((unsigned int *)t76);
    *((unsigned int *)t76) = (t99 & t97);
    t100 = *((unsigned int *)t70);
    *((unsigned int *)t70) = (t100 & t96);
    t101 = *((unsigned int *)t70);
    *((unsigned int *)t70) = (t101 & t97);
    goto LAB25;

LAB26:    *((unsigned int *)t4) = 1;
    goto LAB29;

LAB28:    t108 = (t4 + 4);
    *((unsigned int *)t4) = 1;
    *((unsigned int *)t108) = 1;
    goto LAB29;

LAB30:    t113 = (t0 + 1208U);
    t114 = *((char **)t113);
    goto LAB31;

LAB32:    t113 = (t0 + 1048U);
    t121 = *((char **)t113);
    t113 = (t0 + 1008U);
    t123 = (t113 + 72U);
    t124 = *((char **)t123);
    t125 = ((char*)((ng1)));
    xsi_vlog_generic_get_index_select_value(t122, 32, t121, t124, 2, t125, 32, 1);
    t126 = ((char*)((ng2)));
    memset(t127, 0, 8);
    t128 = (t122 + 4);
    t129 = (t126 + 4);
    t130 = *((unsigned int *)t122);
    t131 = *((unsigned int *)t126);
    t132 = (t130 ^ t131);
    t133 = *((unsigned int *)t128);
    t134 = *((unsigned int *)t129);
    t135 = (t133 ^ t134);
    t136 = (t132 | t135);
    t137 = *((unsigned int *)t128);
    t138 = *((unsigned int *)t129);
    t139 = (t137 | t138);
    t140 = (~(t139));
    t141 = (t136 & t140);
    if (t141 != 0)
        goto LAB42;

LAB39:    if (t139 != 0)
        goto LAB41;

LAB40:    *((unsigned int *)t127) = 1;

LAB42:    memset(t143, 0, 8);
    t144 = (t127 + 4);
    t145 = *((unsigned int *)t144);
    t146 = (~(t145));
    t147 = *((unsigned int *)t127);
    t148 = (t147 & t146);
    t149 = (t148 & 1U);
    if (t149 != 0)
        goto LAB43;

LAB44:    if (*((unsigned int *)t144) != 0)
        goto LAB45;

LAB46:    t151 = (t143 + 4);
    t152 = *((unsigned int *)t143);
    t153 = *((unsigned int *)t151);
    t154 = (t152 || t153);
    if (t154 > 0)
        goto LAB47;

LAB48:    memcpy(t186, t143, 8);

LAB49:    memset(t120, 0, 8);
    t218 = (t186 + 4);
    t219 = *((unsigned int *)t218);
    t220 = (~(t219));
    t221 = *((unsigned int *)t186);
    t222 = (t221 & t220);
    t223 = (t222 & 1U);
    if (t223 != 0)
        goto LAB61;

LAB62:    if (*((unsigned int *)t218) != 0)
        goto LAB63;

LAB64:    t225 = (t120 + 4);
    t226 = *((unsigned int *)t120);
    t227 = *((unsigned int *)t225);
    t228 = (t226 || t227);
    if (t228 > 0)
        goto LAB65;

LAB66:    t231 = *((unsigned int *)t120);
    t232 = (~(t231));
    t233 = *((unsigned int *)t225);
    t234 = (t232 || t233);
    if (t234 > 0)
        goto LAB67;

LAB68:    if (*((unsigned int *)t225) > 0)
        goto LAB69;

LAB70:    if (*((unsigned int *)t120) > 0)
        goto LAB71;

LAB72:    memcpy(t119, t235, 8);

LAB73:    goto LAB33;

LAB34:    xsi_vlog_unsigned_bit_combine(t3, 32, t114, 32, t119, 32);
    goto LAB38;

LAB36:    memcpy(t3, t114, 8);
    goto LAB38;

LAB41:    t142 = (t127 + 4);
    *((unsigned int *)t127) = 1;
    *((unsigned int *)t142) = 1;
    goto LAB42;

LAB43:    *((unsigned int *)t143) = 1;
    goto LAB46;

LAB45:    t150 = (t143 + 4);
    *((unsigned int *)t143) = 1;
    *((unsigned int *)t150) = 1;
    goto LAB46;

LAB47:    t155 = (t0 + 1048U);
    t156 = *((char **)t155);
    t155 = (t0 + 1008U);
    t158 = (t155 + 72U);
    t159 = *((char **)t158);
    t160 = ((char*)((ng2)));
    xsi_vlog_generic_get_index_select_value(t157, 32, t156, t159, 2, t160, 32, 1);
    t161 = ((char*)((ng1)));
    memset(t162, 0, 8);
    t163 = (t157 + 4);
    t164 = (t161 + 4);
    t165 = *((unsigned int *)t157);
    t166 = *((unsigned int *)t161);
    t167 = (t165 ^ t166);
    t168 = *((unsigned int *)t163);
    t169 = *((unsigned int *)t164);
    t170 = (t168 ^ t169);
    t171 = (t167 | t170);
    t172 = *((unsigned int *)t163);
    t173 = *((unsigned int *)t164);
    t174 = (t172 | t173);
    t175 = (~(t174));
    t176 = (t171 & t175);
    if (t176 != 0)
        goto LAB53;

LAB50:    if (t174 != 0)
        goto LAB52;

LAB51:    *((unsigned int *)t162) = 1;

LAB53:    memset(t178, 0, 8);
    t179 = (t162 + 4);
    t180 = *((unsigned int *)t179);
    t181 = (~(t180));
    t182 = *((unsigned int *)t162);
    t183 = (t182 & t181);
    t184 = (t183 & 1U);
    if (t184 != 0)
        goto LAB54;

LAB55:    if (*((unsigned int *)t179) != 0)
        goto LAB56;

LAB57:    t187 = *((unsigned int *)t143);
    t188 = *((unsigned int *)t178);
    t189 = (t187 & t188);
    *((unsigned int *)t186) = t189;
    t190 = (t143 + 4);
    t191 = (t178 + 4);
    t192 = (t186 + 4);
    t193 = *((unsigned int *)t190);
    t194 = *((unsigned int *)t191);
    t195 = (t193 | t194);
    *((unsigned int *)t192) = t195;
    t196 = *((unsigned int *)t192);
    t197 = (t196 != 0);
    if (t197 == 1)
        goto LAB58;

LAB59:
LAB60:    goto LAB49;

LAB52:    t177 = (t162 + 4);
    *((unsigned int *)t162) = 1;
    *((unsigned int *)t177) = 1;
    goto LAB53;

LAB54:    *((unsigned int *)t178) = 1;
    goto LAB57;

LAB56:    t185 = (t178 + 4);
    *((unsigned int *)t178) = 1;
    *((unsigned int *)t185) = 1;
    goto LAB57;

LAB58:    t198 = *((unsigned int *)t186);
    t199 = *((unsigned int *)t192);
    *((unsigned int *)t186) = (t198 | t199);
    t200 = (t143 + 4);
    t201 = (t178 + 4);
    t202 = *((unsigned int *)t143);
    t203 = (~(t202));
    t204 = *((unsigned int *)t200);
    t205 = (~(t204));
    t206 = *((unsigned int *)t178);
    t207 = (~(t206));
    t208 = *((unsigned int *)t201);
    t209 = (~(t208));
    t210 = (t203 & t205);
    t211 = (t207 & t209);
    t212 = (~(t210));
    t213 = (~(t211));
    t214 = *((unsigned int *)t192);
    *((unsigned int *)t192) = (t214 & t212);
    t215 = *((unsigned int *)t192);
    *((unsigned int *)t192) = (t215 & t213);
    t216 = *((unsigned int *)t186);
    *((unsigned int *)t186) = (t216 & t212);
    t217 = *((unsigned int *)t186);
    *((unsigned int *)t186) = (t217 & t213);
    goto LAB60;

LAB61:    *((unsigned int *)t120) = 1;
    goto LAB64;

LAB63:    t224 = (t120 + 4);
    *((unsigned int *)t120) = 1;
    *((unsigned int *)t224) = 1;
    goto LAB64;

LAB65:    t229 = (t0 + 1368U);
    t230 = *((char **)t229);
    goto LAB66;

LAB67:    t229 = (t0 + 1048U);
    t237 = *((char **)t229);
    t229 = (t0 + 1008U);
    t239 = (t229 + 72U);
    t240 = *((char **)t239);
    t241 = ((char*)((ng1)));
    xsi_vlog_generic_get_index_select_value(t238, 32, t237, t240, 2, t241, 32, 1);
    t242 = ((char*)((ng1)));
    memset(t243, 0, 8);
    t244 = (t238 + 4);
    t245 = (t242 + 4);
    t246 = *((unsigned int *)t238);
    t247 = *((unsigned int *)t242);
    t248 = (t246 ^ t247);
    t249 = *((unsigned int *)t244);
    t250 = *((unsigned int *)t245);
    t251 = (t249 ^ t250);
    t252 = (t248 | t251);
    t253 = *((unsigned int *)t244);
    t254 = *((unsigned int *)t245);
    t255 = (t253 | t254);
    t256 = (~(t255));
    t257 = (t252 & t256);
    if (t257 != 0)
        goto LAB77;

LAB74:    if (t255 != 0)
        goto LAB76;

LAB75:    *((unsigned int *)t243) = 1;

LAB77:    memset(t259, 0, 8);
    t260 = (t243 + 4);
    t261 = *((unsigned int *)t260);
    t262 = (~(t261));
    t263 = *((unsigned int *)t243);
    t264 = (t263 & t262);
    t265 = (t264 & 1U);
    if (t265 != 0)
        goto LAB78;

LAB79:    if (*((unsigned int *)t260) != 0)
        goto LAB80;

LAB81:    t267 = (t259 + 4);
    t268 = *((unsigned int *)t259);
    t269 = *((unsigned int *)t267);
    t270 = (t268 || t269);
    if (t270 > 0)
        goto LAB82;

LAB83:    memcpy(t302, t259, 8);

LAB84:    memset(t236, 0, 8);
    t334 = (t302 + 4);
    t335 = *((unsigned int *)t334);
    t336 = (~(t335));
    t337 = *((unsigned int *)t302);
    t338 = (t337 & t336);
    t339 = (t338 & 1U);
    if (t339 != 0)
        goto LAB96;

LAB97:    if (*((unsigned int *)t334) != 0)
        goto LAB98;

LAB99:    t341 = (t236 + 4);
    t342 = *((unsigned int *)t236);
    t343 = *((unsigned int *)t341);
    t344 = (t342 || t343);
    if (t344 > 0)
        goto LAB100;

LAB101:    t347 = *((unsigned int *)t236);
    t348 = (~(t347));
    t349 = *((unsigned int *)t341);
    t350 = (t348 || t349);
    if (t350 > 0)
        goto LAB102;

LAB103:    if (*((unsigned int *)t341) > 0)
        goto LAB104;

LAB105:    if (*((unsigned int *)t236) > 0)
        goto LAB106;

LAB107:    memcpy(t235, t351, 8);

LAB108:    goto LAB68;

LAB69:    xsi_vlog_unsigned_bit_combine(t119, 32, t230, 32, t235, 32);
    goto LAB73;

LAB71:    memcpy(t119, t230, 8);
    goto LAB73;

LAB76:    t258 = (t243 + 4);
    *((unsigned int *)t243) = 1;
    *((unsigned int *)t258) = 1;
    goto LAB77;

LAB78:    *((unsigned int *)t259) = 1;
    goto LAB81;

LAB80:    t266 = (t259 + 4);
    *((unsigned int *)t259) = 1;
    *((unsigned int *)t266) = 1;
    goto LAB81;

LAB82:    t271 = (t0 + 1048U);
    t272 = *((char **)t271);
    t271 = (t0 + 1008U);
    t274 = (t271 + 72U);
    t275 = *((char **)t274);
    t276 = ((char*)((ng2)));
    xsi_vlog_generic_get_index_select_value(t273, 32, t272, t275, 2, t276, 32, 1);
    t277 = ((char*)((ng2)));
    memset(t278, 0, 8);
    t279 = (t273 + 4);
    t280 = (t277 + 4);
    t281 = *((unsigned int *)t273);
    t282 = *((unsigned int *)t277);
    t283 = (t281 ^ t282);
    t284 = *((unsigned int *)t279);
    t285 = *((unsigned int *)t280);
    t286 = (t284 ^ t285);
    t287 = (t283 | t286);
    t288 = *((unsigned int *)t279);
    t289 = *((unsigned int *)t280);
    t290 = (t288 | t289);
    t291 = (~(t290));
    t292 = (t287 & t291);
    if (t292 != 0)
        goto LAB88;

LAB85:    if (t290 != 0)
        goto LAB87;

LAB86:    *((unsigned int *)t278) = 1;

LAB88:    memset(t294, 0, 8);
    t295 = (t278 + 4);
    t296 = *((unsigned int *)t295);
    t297 = (~(t296));
    t298 = *((unsigned int *)t278);
    t299 = (t298 & t297);
    t300 = (t299 & 1U);
    if (t300 != 0)
        goto LAB89;

LAB90:    if (*((unsigned int *)t295) != 0)
        goto LAB91;

LAB92:    t303 = *((unsigned int *)t259);
    t304 = *((unsigned int *)t294);
    t305 = (t303 & t304);
    *((unsigned int *)t302) = t305;
    t306 = (t259 + 4);
    t307 = (t294 + 4);
    t308 = (t302 + 4);
    t309 = *((unsigned int *)t306);
    t310 = *((unsigned int *)t307);
    t311 = (t309 | t310);
    *((unsigned int *)t308) = t311;
    t312 = *((unsigned int *)t308);
    t313 = (t312 != 0);
    if (t313 == 1)
        goto LAB93;

LAB94:
LAB95:    goto LAB84;

LAB87:    t293 = (t278 + 4);
    *((unsigned int *)t278) = 1;
    *((unsigned int *)t293) = 1;
    goto LAB88;

LAB89:    *((unsigned int *)t294) = 1;
    goto LAB92;

LAB91:    t301 = (t294 + 4);
    *((unsigned int *)t294) = 1;
    *((unsigned int *)t301) = 1;
    goto LAB92;

LAB93:    t314 = *((unsigned int *)t302);
    t315 = *((unsigned int *)t308);
    *((unsigned int *)t302) = (t314 | t315);
    t316 = (t259 + 4);
    t317 = (t294 + 4);
    t318 = *((unsigned int *)t259);
    t319 = (~(t318));
    t320 = *((unsigned int *)t316);
    t321 = (~(t320));
    t322 = *((unsigned int *)t294);
    t323 = (~(t322));
    t324 = *((unsigned int *)t317);
    t325 = (~(t324));
    t326 = (t319 & t321);
    t327 = (t323 & t325);
    t328 = (~(t326));
    t329 = (~(t327));
    t330 = *((unsigned int *)t308);
    *((unsigned int *)t308) = (t330 & t328);
    t331 = *((unsigned int *)t308);
    *((unsigned int *)t308) = (t331 & t329);
    t332 = *((unsigned int *)t302);
    *((unsigned int *)t302) = (t332 & t328);
    t333 = *((unsigned int *)t302);
    *((unsigned int *)t302) = (t333 & t329);
    goto LAB95;

LAB96:    *((unsigned int *)t236) = 1;
    goto LAB99;

LAB98:    t340 = (t236 + 4);
    *((unsigned int *)t236) = 1;
    *((unsigned int *)t340) = 1;
    goto LAB99;

LAB100:    t345 = (t0 + 1528U);
    t346 = *((char **)t345);
    goto LAB101;

LAB102:    t345 = (t0 + 1688U);
    t351 = *((char **)t345);
    goto LAB103;

LAB104:    xsi_vlog_unsigned_bit_combine(t235, 32, t346, 32, t351, 32);
    goto LAB108;

LAB106:    memcpy(t235, t346, 8);
    goto LAB108;

}


extern void work_m_00000000002412708881_2421032370_init()
{
	static char *pe[] = {(void *)Cont_77_0};
	xsi_register_didat("work_m_00000000002412708881_2421032370", "isim/mips_test_isim_beh.exe.sim/work/m_00000000002412708881_2421032370.didat");
	xsi_register_executes(pe);
}
